Features
Data source could be chosen, based on the most common random words. Source settings' are independent with each other: lesson generator and minimum performance settings are set for each data source.
Lessons could be customized and generated on-the-fly by varying the Combination, and Repetition settings; you'll immediately see the effect on the generated lesson. Old lessons on the same data source selected will be overridden once you update these settings. Once you completed the lessons, the data will start again at the beginning, but will be re-shuffled.
The WPM/Accuracy wil be updated even at the mid-part of the lessons. You could not proceed to next lesson unless you have met those 100% accuracy.
you could have sample lessons/patterns like this:

Setting: Combination=1, Repetition=3

Output: the the the
Setting: Combination=2, Repetition=3

Output: the and the and the and
Setting: Combination=3, Repetition=3

Output: the and of the and of the and of
Setting: Combination=3, Repetition=1

Output: the and of
Setting: Combination=3, Repetition=2

Output: the and of the and of
# adi-typing-master
